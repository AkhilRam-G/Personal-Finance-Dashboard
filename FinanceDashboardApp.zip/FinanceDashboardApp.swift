import SwiftUI

@main
struct FinanceDashboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
